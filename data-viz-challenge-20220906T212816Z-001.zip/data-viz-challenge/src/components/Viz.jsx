import './Viz.css';

export default function Viz() {
  // TODO : Visualize the data!

  return <main className="viz">Viz goes here</main>;
}
